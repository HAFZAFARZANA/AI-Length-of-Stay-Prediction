export default function AnimatedBackground() {
  return (
    <div className="background">
      <div className="wave"></div>
      <div className="wave delay"></div>

      <span className="symbol">⚕️</span>
      <span className="symbol">🫀</span>
      <span className="symbol">🧬</span>
      <span className="symbol">+</span>
    </div>
  );
}
