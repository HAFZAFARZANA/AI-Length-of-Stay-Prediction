export default function PredictionView({ result, onNext }) {
  return (
    <div className="card full center">
      <h2>🧮 Predicted Length of Stay</h2>
      <div className="los-big">{result.los}</div>
      <button onClick={onNext}>View Clinical Explanation →</button>
    </div>
  );
}
